<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="prtscSafe" tilewidth="32" tileheight="32" tilecount="390" columns="30">
 <image source="prtscSafe.png" width="960" height="443"/>
</tileset>
