<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="whole" tilewidth="32" tileheight="32" tilecount="2444" columns="47">
 <image source="whole.png" width="1504" height="1664"/>
</tileset>
