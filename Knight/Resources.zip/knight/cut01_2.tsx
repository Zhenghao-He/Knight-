<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="cut01_2" tilewidth="32" tileheight="32" tilecount="420" columns="14">
 <image source="cut01_2.png" width="454" height="991"/>
</tileset>
