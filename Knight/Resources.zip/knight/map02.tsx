<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="map02" tilewidth="32" tileheight="32" tilecount="165" columns="15">
 <image source="map02.png" width="500" height="375"/>
</tileset>
