<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="cut01-1" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="cut01-1.png" width="55" height="55"/>
</tileset>
