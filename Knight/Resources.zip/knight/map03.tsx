<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="map03" tilewidth="32" tileheight="32" tilecount="77" columns="11">
 <image source="map03.png" width="383" height="255"/>
</tileset>
