<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="map01" tilewidth="32" tileheight="32" tilecount="210" columns="15">
 <image source="map01.png" width="500" height="468"/>
</tileset>
