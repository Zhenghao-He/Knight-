<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="cut02" tilewidth="32" tileheight="32" tilecount="2660" columns="55">
 <image source="cut02.PNG" width="1780" height="818"/>
</tileset>
