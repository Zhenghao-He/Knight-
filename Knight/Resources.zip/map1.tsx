<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="map1" tilewidth="32" tileheight="32" tilecount="720" columns="30">
 <image source="map1.png" width="986" height="781"/>
</tileset>
