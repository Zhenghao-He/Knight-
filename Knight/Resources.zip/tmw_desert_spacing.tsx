<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="tmw_desert_spacing" tilewidth="32" tileheight="32" tilecount="48" columns="8">
 <image source="tmw_desert_spacing.png" width="265" height="199"/>
</tileset>
